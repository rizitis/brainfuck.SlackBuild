 These are some brainf*** quines which I wrote in search of the smallest
possible one.  I started with t.s (my second brainf*** quine, but the first
seems to have been lost), then came u.s, v.s, x.s, y.s, z.s, z2.s ... z9a.s.
  The *.b files are the bootstraps which I used to generate the respective
quine which are in the *.s files; these are also the files which I actually
edited.